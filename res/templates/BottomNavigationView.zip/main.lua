require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.appcompat.widget.ContentFrameLayout"
import "androidx.fragment.app.FragmentContainerView"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "com.google.android.material.bottomnavigation.BottomNavigationView"
import "com.google.android.material.textview.MaterialTextView"

activity
.setTheme(R.style.Theme_Material3_Blue)
.setTitle("AppName")
.setContentView(loadlayout("layout"))

local function getFragmentView(param)
  return loadlayout({
    LinearLayoutCompat,
    orientation="vertical",
    layout_width="fill",
    layout_height="fill",
    gravity="center",
    {
      MaterialTextView,
      text=param.." Fragment",
      textStyle="bold",
      textSize="28sp",
    },
  })
end

local fragmentManager = this.getSupportFragmentManager()

local Fragments = {}
local Views = {}
Views[1] = getFragmentView("Search")
Views[2] = getFragmentView("Edit")
Views[3] = getFragmentView("Voice")

for k in ipairs(Views) do
  Fragments[k] = LuaFragment().setLayout(Views[k])
end

fragmentManager.beginTransaction().add(FragmentContainer.getId(), Fragments[1]).commit()

local menu=
{
  {
    title = "Search",
    icon = androidx.drawable.abc_ic_search_api_material
  },
  {
    title = "Edit",
    icon = material.drawable.material_ic_edit_black_24dp
  },
  {
    title = "Voice",
    icon = androidx.drawable.abc_ic_voice_search_api_material
  },
}

for k,v in pairs(menu) do
  bottombar.Menu
  .add(0,k-1,k-1,v.title)
  .setIcon(v.icon)
end

bottombar.setOnNavigationItemSelectedListener(BottomNavigationView.OnNavigationItemSelectedListener{
  onNavigationItemSelected=function(item)
    fragmentManager.beginTransaction()
    .setCustomAnimations(
    material.anim.mtrl_bottom_sheet_slide_in,
    material.anim.mtrl_bottom_sheet_slide_out)
    .replace(FragmentContainer.getId(), Fragments[item.getItemId()+1])
    .commit()
    return true
  end
})