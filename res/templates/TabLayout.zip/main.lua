require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.coordinatorlayout.widget.CoordinatorLayout"
import "androidx.viewpager.widget.ViewPager"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatTextView"
import "com.google.android.material.appbar.AppBarLayout"
import "com.google.android.material.tabs.TabLayout"
import "com.google.android.material.appbar.MaterialToolbar"

activity
.setTheme(R.style.Theme_Material3_Blue)
.setTitle("AppName")
.setContentView(loadlayout("layout"))

mTab.setupWithViewPager(cvpg)