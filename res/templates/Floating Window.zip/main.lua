require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.graphics.PixelFormat"
import "android.content.Context"
import "android.content.Intent"
import "android.net.Uri"
import "android.content.Context"
import "android.provider.Settings"
import "android.animation.ObjectAnimator"
import "android.animation.ArgbEvaluator"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "com.google.android.material.button.MaterialButton"
import "com.google.android.material.card.MaterialCardView"
import "androidx.appcompat.widget.AppCompatImageView"

local wmManager = activity.getSystemService(Context.WINDOW_SERVICE)
local wmParams = WindowManager.LayoutParams()
local isFloatingBallOpen = nil
local floatingBall, floatingWindow

activity
.setTheme(R.style.Theme_Material3_Blue)
.setTitle("AppName")
.setContentView(loadlayout("layout"))

if tonumber(Build.VERSION.SDK) >= 26 then
  wmParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else
  wmParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end

wmParams.format = PixelFormat.RGBA_8888
wmParams.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
wmParams.gravity = Gravity.LEFT | Gravity.TOP
wmParams.x = activity.getWidth() / 6
wmParams.y = activity.getHeight() / 5
wmParams.width = WindowManager.LayoutParams.WRAP_CONTENT
wmParams.height = WindowManager.LayoutParams.WRAP_CONTENT

if Build.VERSION.SDK_INT >= Build.VERSION_CODES.M and not Settings.canDrawOverlays(this) then
  print("没有悬浮窗权限悬，请打开权限")
  local intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
  intent.setData(Uri.parse("package:" .. activity.getPackageName()))
  activity.startActivityForResult(intent, 100)
  os.exit()
 else
  floatingBall = loadlayout("xfq")
  floatingWindow = loadlayout("xfc")
end

function open.onClick()
  if isFloatingBallOpen == nil then
    wmManager.addView(floatingBall, wmParams)
    isFloatingBallOpen = true
   else
    print("你已启动悬浮窗")
  end
end

local function expand()
  wmManager.addView(floatingWindow, wmParams)
  wmManager.removeView(floatingBall)
end

local function hide()
  wmManager.removeView(floatingWindow)
  wmManager.addView(floatingBall, wmParams)
end

local function exit()
  wmManager.removeView(floatingWindow)
  isFloatingBallOpen = nil
end

function Close.onClick()
  exit()
end

function Min.onClick()
  hide()
end

function Logo.OnTouchListener(v, event)
  local action = event.getAction()
  if action == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
   elseif action == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(floatingBall, wmParams)
  end
  return false
end

function Logo.onClick()
  expand()
end

function Windows.OnTouchListener(v, event)
  local action = event.getAction()
  if action == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = wmParams.x
    wmY = wmParams.y
   elseif action == MotionEvent.ACTION_MOVE then
    wmParams.x = wmX + (event.getRawX() - firstX)
    wmParams.y = wmY + (event.getRawY() - firstY)
    wmManager.updateViewLayout(floatingWindow, wmParams)
  end
  return false
end