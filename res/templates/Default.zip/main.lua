require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.appcompat.widget.LinearLayoutCompat"

activity
.setTheme(R.style.Theme_Material3_Blue)
.setTitle("AppName")
.setContentView(loadlayout("layout"))