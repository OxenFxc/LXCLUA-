require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.graphics.drawable.GradientDrawable"
import "androidx.appcompat.app.ActionBarDrawerToggle"
import "androidx.drawerlayout.widget.DrawerLayout"
import "androidx.coordinatorlayout.widget.CoordinatorLayout"
import "androidx.viewpager.widget.ViewPager"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatImageView"
import "androidx.appcompat.widget.AppCompatTextView"
import "com.google.android.material.floatingactionbutton.FloatingActionButton"
import "com.google.android.material.navigation.NavigationView"
import "com.google.android.material.snackbar.Snackbar"
import "com.google.android.material.appbar.AppBarLayout"
import "com.google.android.material.appbar.MaterialToolbar"
import "IconDrawable"

activity
.setTheme(R.style.Theme_Material3_Blue_NoActionBar)
.setTitle("AppName")
.setContentView(loadlayout("layout"))
.setSupportActionBar(toolbar)
.getSupportActionBar()
.setDisplayHomeAsUpEnabled(true)

local toggle = ActionBarDrawerToggle(this, drawer_layout, R.string.open_drawer, R.string.close_drawer)
drawer_layout.setDrawerListener(toggle)
toggle.syncState()

function onOptionsItemSelected(item)
  if item.ItemId == android.R.id.home
    if not drawer_layout.isDrawerOpen(3)
      drawer_layout.openDrawer(3)
     else
      drawer_layout.closeDrawer(3)
    end
  end
end

fab.onClick = function(view)
  Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show()
end

nav_view.addHeaderView(loadlayout("nav_header_main"))

local menu=
{
  {
    title = "Search",
    icon = androidx.drawable.abc_ic_search_api_material
  },
  {
    title = "Edit",
    icon = material.drawable.material_ic_edit_black_24dp
  },
  {
    title = "Voice",
    icon = androidx.drawable.abc_ic_voice_search_api_material
  },
}

for k,v pairs(menu)
  nav_view.Menu.add(0,k-1,k-1,v.title).setIcon(v.icon).setCheckable(true)
end

nav_view.setCheckedItem(0)
nav_view.invalidate()

nav_view.setNavigationItemSelectedListener(NavigationView.OnNavigationItemSelectedListener{
  onNavigationItemSelected=function(item)
    nav_view.invalidate()
    cvpg.setCurrentItem(item.getItemId())
    return true
  end
})

nav_header.backgroundDrawable = GradientDrawable(GradientDrawable.Orientation.TR_BL,{ 0xFF4DB6AC, 0xFF009688, 0xFF00695C })

cvpg.addOnPageChangeListener(ViewPager.OnPageChangeListener{
  onPageSelected = function(position)
    nav_view.setCheckedItem(position)
    nav_view.invalidate()
  end
})