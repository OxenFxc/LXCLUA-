require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "androidx.appcompat.widget.LinearLayoutCompat"
import "androidx.appcompat.widget.AppCompatTextView"
import "androidx.coordinatorlayout.widget.CoordinatorLayout"
import "com.google.android.material.appbar.AppBarLayout"
import "com.google.android.material.floatingactionbutton.FloatingActionButton"
import "com.google.android.material.appbar.MaterialToolbar"
import "com.google.android.material.snackbar.Snackbar"

activity
.setTheme(R.style.Theme_Material3_Blue)
.setTitle("AppName")
.setContentView(loadlayout("layout"))

function fab.onClick()
  Snackbar
  .make(coordinator, "This a Snackbar", Snackbar.LENGTH_SHORT)
  .show()
end